{
	"lang": {
		"en_US": {
		    "Warn": "AUTORESTART-PLUGIN: AUTORESTART-WARNING",
    		"TimeWarn": "AUTORESTART-PLUGIN: BOT WILL RESTART AFTER {0} MINUTES BEGIN NOW!",
	    	"RestartWarn": "AUTORESTART-PLUGIN:  BOT IS RESTARTING!"
    	},
	    "vi_VN": {
		    "Warn": "PLUGIN AUTORESTART: CẢNH BÁO AUTORESTART",
    		"TimeWarn": "PLUGIN AUTORESTART: BOT SẼ KHỞI ĐỘNG LẠI SAU {0} PHÚT KỂ TỪ BÂY GIỜ!",
	    	"RestartWarn": "PLUGIN AUTORESTART: BOT ĐANG KHỞI ĐỘNG LẠI!"
	    }
    },
	"langdes": {
		"Warn": [],
	    "TimeWarn": ["{0}"],
	    "RestartWarn": []
	}
}
