# CustomAlerts PLUGIN #

<img alt="HitsCounter" src="http://hits.dwyl.com/Kaysil/CustomAlert.svg"> <img alt="GitHub all releases" src="https://img.shields.io/github/downloads/Kaysil/CustomAlerts/total?color=dd&style=flat-square"> <img alt="GitHub code size" src="https://img.shields.io/github/languages/code-size/Kaysil/CustomAlerts?style=flat-square">

### CustomAlerts plugin for C3CBot
### Author: Kaysil (me) ##

### Usage/Using:
- Put it to ./plugins folder then run your bot

#### Config:
- 

#### Command:
- Main command: none

#### Example:
- none

#### When a user join/leave the bot will message like Discord
